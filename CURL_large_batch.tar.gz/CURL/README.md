# [Batch Size > 1 version of CURL: Neural Curve Layers for Global Image Enhancement (ICPR 2020)](https://github.com/sjmoran/CURL)
I have changed two files from the original repository. Model.py is changed to NEW_MODEL.py and util.py is changed to new_util.py.
